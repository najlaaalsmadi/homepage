import 'dart:js';

import 'package:flutter/material.dart';
import 'package:task1_register/home/components/home_screen.dart';

final Map<String,WidgetBuilder> routes={
  HomeScreen.routeName:(context)=>HomeScreen(),
};