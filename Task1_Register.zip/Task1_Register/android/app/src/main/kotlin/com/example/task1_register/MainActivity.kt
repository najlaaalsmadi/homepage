package com.example.task1_register

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
